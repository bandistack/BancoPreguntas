// URL de tu Worker (sin "/" al final). Cámbiala antes de subir la extensión.
const API_URL = 'https://twitch-panel-ebs.andresestebanposada.workers.dev';

let jwt = null;
let data = null;
let failed = false;
let tab = 'bits';

const view = document.getElementById('view');

/* ---------- Twitch ---------- */

// Se dispara al inicio y cada vez que Twitch renueva el JWT.
Twitch.ext.onAuthorized((auth) => {
  jwt = auth.token;
  load();
});

async function load() {
  if (!jwt) return;
  try {
    const res = await fetch(`${API_URL}/data`, { headers: { Authorization: `Bearer ${jwt}` } });
    if (!res.ok) throw new Error(res.status);
    data = await res.json();
    failed = false;
  } catch {
    failed = true;
  }
  render();
}
setInterval(load, 120_000);

/* ---------- Helpers ---------- */

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
}

const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

// "2 años 3 meses", "5 meses", "12 días"...
function tenure(iso) {
  const a = new Date(iso);
  const b = new Date();
  let months = (b.getFullYear() - a.getFullYear()) * 12 + (b.getMonth() - a.getMonth());
  if (b.getDate() < a.getDate()) months--;
  if (months >= 12) {
    const y = Math.floor(months / 12);
    const m = months % 12;
    return plural(y, 'año', 'años') + (m ? ' ' + plural(m, 'mes', 'meses') : '');
  }
  if (months >= 1) return plural(months, 'mes', 'meses');
  const days = Math.floor((b - a) / 864e5);
  if (days >= 1) return plural(days, 'día', 'días');
  return 'menos de un día';
}

// "hace 5 min", "hace 3 h", "hace 2 días"
function ago(iso) {
  const s = Math.max(0, (Date.now() - new Date(iso)) / 1000);
  if (s < 60) return 'ahora';
  if (s < 3600) return `hace ${Math.floor(s / 60)} min`;
  if (s < 86400) return `hace ${Math.floor(s / 3600)} h`;
  return `hace ${plural(Math.floor(s / 86400), 'día', 'días')}`;
}

const tierName = (t) => ({ 1000: 'Tier 1', 2000: 'Tier 2', 3000: 'Tier 3' }[t] || 'Tier 1');

function row({ rank, name, note, value }) {
  const li = el('li', 'row');
  if (rank !== undefined) li.append(el('span', 'rank' + (rank <= 3 ? ' top' : ''), String(rank)));
  const who = el('div', 'who');
  who.append(el('div', 'name', name));
  if (note) who.append(el('div', 'note', note));
  li.append(who);
  if (value) li.append(el('span', 'val', value));
  return li;
}

function list(rows, emptyText) {
  if (!rows || !rows.length) return el('p', 'empty', emptyText);
  const ul = el('ul', 'list');
  rows.forEach((r) => ul.append(row(r)));
  return ul;
}

/* ---------- Render ---------- */

function failMsg(text) {
  return el('p', 'empty', text + (data.errors && data.errors.length ? ' ' + data.errors.join(' / ') : ''));
}

function render() {
  document.querySelectorAll('.tabs button').forEach((b) =>
    b.setAttribute('aria-selected', String(b.dataset.tab === tab))
  );

  if (!data) {
    view.replaceChildren(el('p', 'empty', failed ? 'No se pudo cargar. Reintentando en un minuto.' : 'Cargando…'));
    return;
  }

  let content;
  if (tab === 'bits') {
    content = data.bits === null
      ? failMsg('No se pudo leer el ranking de sponsors.')
      : list(
          data.bits.map((b) => ({ rank: b.rank, name: b.user, value: `${b.score.toLocaleString('es')} bits` })),
          'Todavía no hay sponsors.'
        );
  } else if (tab === 'subs') {
    content = data.subs === null
      ? failMsg('No se pudo leer la lista de subs.')
      : list(
          data.subs.list.map((s) => ({
            name: s.user,
            note: s.gift === null ? tierName(s.tier) : `${tierName(s.tier)}, regalado${s.gift ? ' por ' + s.gift : ''}`,
            value: s.at ? ago(s.at) : '',
          })),
          'Aún no hay subs.'
        );
  } else {
    content = data.followers === null
      ? failMsg('No se pudo leer la lista de seguidores.')
      : list(
          data.followers.map((f) => ({ name: f.user, note: `Lleva ${tenure(f.at)} en el canal` })),
          'Aún no hay seguidores.'
        );
  }
  view.replaceChildren(content);
}

document.querySelectorAll('.tabs button').forEach((b) => {
  b.onclick = () => { tab = b.dataset.tab; render(); };
});
