const BANK_URL = "https://bandistack.github.io/BancoPreguntas/bank.json";
const ROUND = 5;
const FALLBACK = [
  { c: "General", q: "Los wombats hacen caca en forma de cubos.", a: 1, why: "Real: así no se les ruedan y marcan territorio." },
  { c: "General", q: "Los pulpos tienen tres corazones.", a: 1, why: "Real. Dos para las branquias y uno para el cuerpo." },
  { c: "General", q: "Las bananas son bayas, pero las fresas no.", a: 1, why: "Real. Botánicamente es así." },
  { c: "General", q: "Las nutrias duermen tomadas de la mano.", a: 1, why: "Real. Así no se separan mientras flotan." },
  { c: "General", q: "Cleopatra vivió más cerca del primer iPhone que de la Gran Pirámide.", a: 1, why: "Real. La pirámide ya era antigua para ella." },
  { c: "General", q: "Los flamencos nacen rosados.", a: 0, why: "Inventado. Nacen grises y se ponen rosados por lo que comen." },
  { c: "General", q: "Los murciélagos son ciegos.", a: 0, why: "Inventado. Ven bien, y además tienen eco de regalo." },
  { c: "General", q: "Solo usamos el 10% del cerebro.", a: 0, why: "Inventado. Usas todo, incluso viendo videos de gatos." },
  { c: "General", q: "Los avestruces esconden la cabeza en la arena.", a: 0, why: "Inventado. Solo la bajan para cuidar su nido." },
  { c: "General", q: "Napoleón era bajísimo.", a: 0, why: "Inventado. Medía cerca de 1,68 m, normal para su época." }
];
const RANKS = [
  "Cero. Hay que ser muy constante para lograrlo.",
  "Tu instinto es una brújula rota.",
  "Dudoso, pero simpático.",
  "Aprobado, con reservas.",
  "Casi insoportablemente culto.",
  "Sospechosamente perfecto. ¿Buscaste en Google?"
];

let cfg = {}, bank = FALLBACK, loaded = false, cat = "", deck = [], i = 0, score = 0, marks = [];
const $ = (id) => document.getElementById(id);
const show = (id) => ["start", "game", "end"].forEach((x) => ($(x).hidden = x !== id));

const get = (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } };
const set = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };
const hash = (s) => { let h = 5381; for (const ch of s) h = ((h << 5) + h + ch.charCodeAt(0)) | 0; return (h >>> 0).toString(36); };
const seen = () => { try { return new Set(JSON.parse(get("roi-seen") || "[]")); } catch (e) { return new Set(); } };

function pool() {
  const mine = (Array.isArray(cfg.questions) ? cfg.questions : []).map((x) => ({ ...x, c: "Del canal" }));
  return cfg.onlyMine && mine.length >= ROUND ? mine : bank.concat(mine);
}

function shuffle(a) {
  for (let n = a.length - 1; n > 0; n--) {
    const k = Math.floor(Math.random() * (n + 1));
    [a[n], a[k]] = [a[k], a[n]];
  }
  return a;
}

function home() {
  $("title").textContent = cfg.title || "¿Real o inventado?";
  const b = +get("roi-best") || 0;
  $("best").textContent = b ? "Tu récord: " + b + " de " + ROUND : "";
  const box = $("cats");
  box.replaceChildren();
  const all = document.createElement("button");
  all.className = "all";
  all.textContent = "Todos los temas";
  all.onclick = () => start("");
  box.appendChild(all);
  [...new Set(pool().map((x) => x.c))].forEach((c) => {
    const b2 = document.createElement("button");
    b2.textContent = c;
    b2.onclick = () => start(c);
    box.appendChild(b2);
  });
  show("start");
}

function start(c) {
  if (c !== undefined) cat = c;
  const items = pool().filter((x) => !cat || x.c === cat);
  const s = seen();
  let fresh = items.filter((x) => !s.has(hash(x.q)));
  if (fresh.length < ROUND) {
    items.forEach((x) => s.delete(hash(x.q)));
    set("roi-seen", JSON.stringify([...s]));
    fresh = items;
  }
  deck = shuffle(fresh.slice()).slice(0, ROUND);
  i = 0; score = 0; marks = [];
  show("game");
  ask();
}

function dots() {
  $("dots").replaceChildren(...deck.map((_, n) => {
    const d = document.createElement("i");
    d.className = marks[n] || (n === i ? "now" : "");
    return d;
  }));
  $("count").textContent = i + 1 + " / " + deck.length;
}

function ask() {
  $("q").textContent = deck[i].q;
  $("fb").hidden = true;
  document.querySelectorAll("#ans button").forEach((b) => { b.disabled = false; b.classList.remove("sel", "right"); });
  dots();
}

function answer(v) {
  const c = deck[i], ok = v === c.a;
  if (ok) score++;
  marks[i] = ok ? "ok" : "bad";
  const s = seen(); s.add(hash(c.q)); set("roi-seen", JSON.stringify([...s]));
  document.querySelectorAll("#ans button").forEach((b) => {
    b.disabled = true;
    b.classList.toggle("sel", +b.dataset.a === v);
    b.classList.toggle("right", +b.dataset.a === c.a);
  });
  $("verdict").textContent = ok ? "¡Correcto!" : "Nope.";
  $("verdict").className = ok ? "ok" : "bad";
  $("why").textContent = c.why;
  $("next").textContent = i === deck.length - 1 ? "Ver resultado" : "Siguiente";
  $("fb").hidden = false;
  dots();
}

function finish() {
  const total = deck.length, b = +get("roi-best") || 0;
  $("score").textContent = score + " / " + total;
  $("rank").textContent = RANKS[Math.round((score / total) * 5)];
  $("newbest").textContent = score > b ? "¡Nuevo récord!" : "Tu récord: " + b + " de " + ROUND;
  if (score > b) set("roi-best", score);
  show("end");
}

async function loadBank() {
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 6000);
    const r = await fetch(BANK_URL, { signal: ctl.signal });
    clearTimeout(t);
    if (!r.ok) throw new Error("http");
    const ok = (await r.json()).filter((x) => x && typeof x.q === "string" && (x.a === 0 || x.a === 1));
    if (ok.length >= ROUND) bank = ok.map((x) => ({ c: x.c || "General", q: x.q, a: x.a, why: x.why || "" }));
  } catch (e) { bank = FALLBACK; }
  loaded = true;
  if (!$("start").hidden) home();
}

function loadCfg() {
  try {
    const c = window.Twitch.ext.configuration.broadcaster;
    cfg = c && c.content ? JSON.parse(c.content) : {};
  } catch (e) { cfg = {}; }
  if (loaded && !$("start").hidden) home();
}

$("again").onclick = () => start();
$("menu").onclick = home;
$("next").onclick = () => { if (++i >= deck.length) finish(); else ask(); };
document.querySelectorAll("#ans button").forEach((b) => (b.onclick = () => answer(+b.dataset.a)));

if (window.Twitch && window.Twitch.ext) window.Twitch.ext.configuration.onChanged(loadCfg);
loadBank();
