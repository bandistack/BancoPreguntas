const $ = (id) => document.getElementById(id);

function fill() {
  const c = window.Twitch.ext.configuration.broadcaster;
  if (!c || !c.content) return;
  try {
    const d = JSON.parse(c.content);
    $("t").value = d.title || "";
    $("only").checked = !!d.onlyMine;
    $("qs").value = (d.questions || []).map((x) => [x.q, x.a ? "V" : "F", x.why].join(" | ")).join("\n");
  } catch (e) {}
}

$("save").addEventListener("click", () => {
  const questions = $("qs").value.split("\n")
    .map((l) => l.split("|").map((p) => p.trim()))
    .filter((p) => p[0] && /^[vf]$/i.test(p[1] || ""))
    .map((p) => ({ q: p[0], a: /^v$/i.test(p[1]) ? 1 : 0, why: p[2] || "" }));
  const json = JSON.stringify({ title: $("t").value.trim(), onlyMine: $("only").checked, questions });
  if (json.length > 4800) {
    $("msg").textContent = "Demasiado texto: el límite es de unos 5 KB. Quita algunas afirmaciones.";
    return;
  }
  window.Twitch.ext.configuration.set("broadcaster", "1", json);
  $("msg").textContent = "Guardado: " + questions.length + " afirmaciones.";
});

window.Twitch.ext.configuration.onChanged(fill);
