(function () {
  var root = document.documentElement;
  var KEY = "tema";
  var manual = null;
  var twitch = null;

  function read() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
  function write(v) { try { localStorage.setItem(KEY, v); } catch (e) {} }

  var saved = read();
  if (saved === "light" || saved === "dark") manual = saved;

  function actual() {
    if (manual) return manual;
    if (twitch) return twitch;
    return window.matchMedia && matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  }

  function apply() {
    var t = actual();
    root.dataset.theme = t;
    document.querySelectorAll("[data-toggle-tema]").forEach(function (b) {
      b.textContent = t === "light" ? "Oscuro" : "Claro";
      b.setAttribute("aria-label", t === "light" ? "Cambiar a tema oscuro" : "Cambiar a tema claro");
    });
  }

  document.querySelectorAll("[data-toggle-tema]").forEach(function (b) {
    b.addEventListener("click", function () {
      manual = actual() === "light" ? "dark" : "light";
      write(manual);
      apply();
    });
  });

  if (window.Twitch && window.Twitch.ext) {
    window.Twitch.ext.onContext(function (ctx) {
      if (ctx && ctx.theme) {
        twitch = ctx.theme === "light" ? "light" : "dark";
        apply();
      }
    });
  }

  apply();
})();
