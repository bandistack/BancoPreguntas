const $ = (id) => document.getElementById(id);
let SITIO = {};
let PRODUCTOS = [];
let filtro = "";

const etiqueta = (k, defecto) => (SITIO.etiquetas && SITIO.etiquetas[k]) || defecto;

function poner(el, texto) {
  const t = (texto === undefined || texto === null ? "" : texto).toString().trim();
  el.textContent = t;
  el.hidden = !t;
}

function aplicarSitio(s) {
  SITIO = s || {};
  if (SITIO.idioma) document.documentElement.lang = SITIO.idioma;
  poner($("titulo"), SITIO.titulo);
  if (SITIO.logo) {
    $("logo").src = SITIO.logo;
    $("logo").alt = SITIO.titulo || "";
    $("logo").hidden = false;
  }
  $("volver").textContent = etiqueta("volver", "←");
}

function formatearPrecio(p) {
  if (typeof p !== "number") return p.toString();
  const n = SITIO.locale ? p.toLocaleString(SITIO.locale) : String(p);
  return (SITIO.moneda || "") + n;
}

const hayPrecio = (p) => p.price !== undefined && p.price !== null && p.price !== "";

/* ---------- Filtros ---------- */
function pintarFiltros() {
  const cats = [...new Set(PRODUCTOS.map((p) => p.categoria).filter(Boolean))];
  const box = $("filtros");
  box.replaceChildren();
  if (cats.length < 2) { box.hidden = true; return; }
  [["", etiqueta("todos", "Todos")], ...cats.map((c) => [c, c])].forEach(([valor, texto]) => {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = texto;
    b.dataset.valor = valor;
    b.onclick = () => { filtro = valor; pintarFiltros(); pintarCatalogo(); };
    b.classList.toggle("on", valor === filtro);
    box.appendChild(b);
  });
  box.hidden = false;
}

/* ---------- Catálogo ---------- */
function pintarCatalogo() {
  const grid = $("grid");
  grid.replaceChildren();
  grid.scrollTop = 0;
  PRODUCTOS.filter((p) => !filtro || p.categoria === filtro).forEach((p) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "card";

    const im = document.createElement("span");
    im.className = "im";
    const img = document.createElement("img");
    img.src = p.imagen;
    img.alt = "";
    img.loading = "lazy";
    im.appendChild(img);

    const nm = document.createElement("span");
    nm.className = "nm";
    nm.textContent = p.nombre;

    b.append(im, nm);
    if (hayPrecio(p)) {
      const pr = document.createElement("span");
      pr.className = "pr";
      pr.textContent = formatearPrecio(p.price);
      b.appendChild(pr);
    }
    b.onclick = () => abrir(p);
    grid.appendChild(b);
  });
}

/* ---------- Detalle ---------- */
function abrir(p) {
  $("foto").src = p.imagen;
  $("foto").alt = p.nombre;
  $("nombre").textContent = p.nombre;
  poner($("precio"), hayPrecio(p) ? formatearPrecio(p.price) : "");
  poner($("desc"), p.descripcion);

  const dl = $("detalles");
  dl.replaceChildren();
  const pares = Object.entries(p.detalles || {});
  pares.forEach(([k, v]) => {
    const dt = document.createElement("dt"); dt.textContent = k;
    const dd = document.createElement("dd"); dd.textContent = v;
    dl.append(dt, dd);
  });
  dl.hidden = pares.length === 0;

  $("catalogo").hidden = true;
  $("detalle").hidden = false;
  document.querySelector(".ficha").scrollTop = 0;
  $("volver").focus({ preventScroll: true });
}

function cerrar() {
  $("detalle").hidden = true;
  $("catalogo").hidden = false;
}
$("volver").onclick = cerrar;

/* ---------- Carga ---------- */
fetch("merch.json")
  .then((r) => {
    if (!r.ok) throw new Error("No se encontró merch.json (" + r.status + ")");
    return r.json();
  })
  .then((datos) => {
    aplicarSitio(datos.sitio);
    PRODUCTOS = datos.productos || [];
    if (!PRODUCTOS.length) throw new Error("La lista de productos está vacía");
    pintarFiltros();
    pintarCatalogo();
  })
  .catch((err) => {
    const p = document.createElement("p");
    p.className = "desc";
    p.textContent = "Error: " + err.message;
    $("grid").replaceChildren(p);
    console.error(err);
  });
